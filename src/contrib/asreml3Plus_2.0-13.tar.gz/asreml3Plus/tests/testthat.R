Sys.setenv("R_TESTS" = "")
library(testthat)
test_check("asreml3Plus")
