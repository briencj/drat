#Deprecations

getDates <- function(...)
{ .Deprecated(new = "getTimesSubset", package = "growthPheno")
  invisible()
}

# anomPlot <- function(...)
# { .Deprecated(new = "plotAnom", package = "growthPheno")
#   invisible()
# }
# 
# corrPlot <- function(...)
# { .Deprecated(new = "plotCorrmatrix", package = "growthPheno")
#   invisible()
# }
# 
# imagetimesPlot <- function(...)
# { .Deprecated(new = "plotImagetimes", package = "growthPheno")
#   invisible()
# }
# 
# longiPlot <- function(...)
# { .Deprecated(new = "plotLongitudinal", package = "growthPheno")
#   invisible()
# }
