#devtools::test("dae")
context("Ameasures")

cat("#### Test for  using Cochran&Cox PBIBD2\n")
test_that("SmithSmall", {
  skip_on_cran()
  library(dae)
  #'# Script to investigate the reduced design from Smith et al. (2015)

  #'## Set up designs
  mill.fac <- fac.gen(list(Mrep = 2, Mday = 2, Mord = 3))
  field.lay <- fac.gen(list(Frep = 2, Fplot = 4))
  field.lay$Variety <- factor(c("D","E","Y","W","G","D","E","M"), 
                              levels = c("Y","W","G","M","D","E"))
  start.design <- cbind(mill.fac, field.lay[c(3,4,5,8,1,7,3,4,5,8,6,2),])
  rownames(start.design) <- NULL
  start.design

  #'## Set gammas
  terms <- c("Variety", "Frep", "Frep:Fplot", "Mrep", "Mrep:Mday", "Mrep:Mday:Mord")
  gammas <- c(1, 0.1, 0.2, 0.3, 0.2, 1)
  names(gammas) <- terms
  print(gammas)
  
  #'## Examine A-optimality measures
  #'### Set up functions
  "invInf" <- function(design, gammas, ...)
  {
    #'## Set up matrices
    W <- model.matrix(~ -1 + Variety, design)
    ZMr <- model.matrix(~ -1 + Mrep, design)
    ZMrMd <- model.matrix(~ -1 + Mrep:Mday, design)
    ZFr <- model.matrix(~ -1 + Frep, design)
    ZFrFp <- model.matrix(~ -1 + Frep:Fplot, design)
    t <- length(levels(design$Variety))
    ng <- ncol(W)
    Vu <- gammas["Mrep"] * ZMr %*% t(ZMr) + gammas["Mrep:Mday"] * ZMrMd %*% t(ZMrMd) + 
      gammas["Frep"] * ZFr %*% t(ZFr) + gammas["Frep:Fplot"] * ZFrFp %*% t(ZFrFp)
    R <- diag(1, nrow(design))
    
    #'# Calculate information matrix
    Vp <- mat.Vpred(W = W, Vu=Vu, R=R, ...)
    
    return(Vp)
  }
  
  
  #'## Calculate A measures
  Vp <- invInf(start.design, gammas)
  testthat::expect_true(all(abs(designAmeasures(Vp) - 1.521905) < 1e-6))
  n <- nrow(start.design)
  Vp.reduc <- invInf(start.design, gammas, 
                     eliminate = projector(matrix(1, nrow = n, ncol = n)/n))
  testthat::expect_true(all(abs(rowSums(Vp.reduc)) < 1e-10))
  testthat::expect_true(abs(designAmeasures(Vp.reduc) - 
                              sum(diag(Vp.reduc)) * 2 / (nrow(Vp.reduc) - 1)) < 1.e-10)
  
  #'## Investigate the anatomy
  start2.canon <- designAnatomy(list(lab = ~ Mrep/Mday/Mord, 
                                     plot = ~ Frep/Fplot),
                                data = start.design, omit.projectors = "pcanon")
  testthat::expect_equal(degfree(start2.canon$Q[[2]]$`Mord[Mrep:Mday]&Fplot[Frep]`), 5)
})  

cat("#### Test for Ameasures using Cochran&Cox PBIBD2\n")
test_that("PBIBD2Ameasures", {
  skip_on_cran()
  library(dae)
  #'# PBIBD(2) from p. 379 of Cochran and Cox (1957) Experimental Designs. 2nd edn Wiley, New York"
  
  #'## Input the design and randomize"
  Treatments <- factor(c(1,4,2,5, 2,5,3,6, 3,6,1,4, 4,1,5,2, 5,2,6,3, 6,3,4,1))
  PBIBD2.lay <- designRandomize(allocated = Treatments,
                                recipient = list(Blocks =6, Units = 4),
                                nested.recipients = list(Units = "Blocks"),
                                seed = 98177)
  
  #'## Compute the anatomy
  PBIBD2.canon <- designAnatomy(formulae = list(unit = ~Blocks/Units,
                                                trt = ~ Treatments),
                                which.criteria = c('aeff', 'xeff', 'eeff','order'),
                                data = PBIBD2.lay, omit.projectors = "combined")
  
  
  testthat::expect_equal(PBIBD2.canon$Q[[1]]$Blocks$Treatments$adjusted$aefficiency, 0.25)
  testthat::expect_lt(abs(PBIBD2.canon$Q[[1]]$`Units[Blocks]`$Treatments$adjusted$aefficiency - 0.8824), 1e-04)
  
  #'## Get Ameasure
  #'## Set up matrices
  W <- model.matrix(~ -1 + Treatments, PBIBD2.lay)
  Vu <- with(PBIBD2.lay, fac.vcmat(Blocks, 5))
  R <- diag(1, nrow(PBIBD2.lay))
  
  #'## Calculate the variance matrix of the predictions
  Vp <- mat.Vpred(W = W, Vu=Vu, R=R)
  designAmeasures(Vp)
  
  #'## Get reduced variance matix of predictions
  unit.str <- pstructure(~Blocks/Units, grandMean = TRUE, data = PBIBD2.lay)
  Q.B <- projector(unit.str$Q$Mean + unit.str$Q$Blocks)
  testthat::expect_equal(degfree(Q.B), 6)
  Vp.reduc <- mat.Vpred(W = W, Vu=Vu, R=R, eliminate = Q.B)
  testthat::expect_true(all(abs(rowSums(Vp.reduc)) < 1e-10))
  testthat::expect_true(abs(designAmeasures(Vp.reduc) - 
                              2/(4*PBIBD2.canon$Q[[1]]$`Units[Blocks]`$Treatments$adjusted$aefficiency)) 
                        < 1e-10)
})

