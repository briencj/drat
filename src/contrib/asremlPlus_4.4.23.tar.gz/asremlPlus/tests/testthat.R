Sys.setenv("R_TESTS" = "")
library(testthat)
#Need to execute the following for manual checking
#Sys.setenv(NOT_CRAN = "true")
#setwd("~/Analyses/R/asremlPlus/tests/")
#test_check("asremlPlus", filter = "3Wheat")
#test_check("asremlPlus", filter = "41Wheat")
#test_check("asremlPlus", filter = "42Wheat")
#test_check("asremlPlus", filter = "3")
#test_check("asremlPlus", filter = "42alldiffsasr")
#test_check("asremlPlus", filter = "42alldiffslme")
#test_check("asremlPlus", filter = "42bootREMLRTWheat")
#test_check("asremlPlus", filter = "42ChangeTerms")
#test_check("asremlPlus", filter = "42EstimateV")
#test_check("asremlPlus", filter = "42GeneticCane")
#test_check("asremlPlus", filter = "42glm")
#test_check("asremlPlus", filter = "42HEB25estimateV")
#test_check("asremlPlus", filter = "42MET")
#test_check("asremlPlus", filter = "42Orange")
#test_check("asremlPlus", filter = "42Parallel")
#test_check("asremlPlus", filter = "42PredictionsFrame")
#test_check("asremlPlus", filter = "42PredictionsPresentation") # do separately
#test_check("asremlPlus", filter = "42REMLRTIC") # do separately
#test_check("asremlPlus", filter = "42Selection")
#test_check("asremlPlus", filter = "42Simulate")
#test_check("asremlPlus", filter = "42Sortalldiffs")
#test_check("asremlPlus", filter = "42SpatialModels") # do separately
#test_check("asremlPlus", filter = "42Variofaces")
#test_check("asremlPlus", filter = "42WheatSpatialVignette") # do separately
#test_check("asremlPlus", filter = "42WheatVignette") # do separately
#test_check("asremlPlus", filter = "42S[a-o]")
#test_check("asremlPlus", filter = "42[A-R]")
#test_check("asremlPlus", filter = "42[V-W]")
#test_check("asremlPlus", filter = "42S")

#test_check("asremlPlus", filter = "42")
#test_check("asremlPlus", filter = "41")
#test_check("asremlPlus")
