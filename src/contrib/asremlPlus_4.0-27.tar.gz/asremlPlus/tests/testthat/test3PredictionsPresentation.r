#devtools::test("asremlPlus")
context("prediction_presentation3")

cat("#### Test for predictPlus.asreml3\n")
test_that("predictPlus_asreml3", {
  skip_if_not_installed("asreml")
  skip_on_cran()
  library(asreml)
  library(asremlPlus)
  library(dae)
  unloadNamespace("asreml4")
  data(WaterRunoff.dat)
  testthat::expect_output(current.asr <- asreml(fixed = pH ~ Benches + (Sources * (Type + Species)), 
                                                random = ~ Benches:MainPlots,
                                                keep.order=TRUE, data= WaterRunoff.dat))
  current.asrt <- asrtests(current.asr, NULL, NULL)
  diffs <- predictPlus.asreml(classify = "Sources:Type", 
                              asreml.obj = current.asr, tables = "none", 
                              wald.tab = current.asrt$wald.tab, 
                              present = c("Type","Species","Sources"))
  testthat::expect_is(diffs, "alldiffs")
  
  #### Get the observed combinations of the factors and variables in classify
  class.facs <- c("Species","Date","xDay")
  levs <- as.data.frame(table(WaterRunoff.dat[class.facs]))
  levs <- levs[do.call(order, levs), ]
  levs <- as.list(levs[levs$Freq != 0, class.facs])
  levs$xDay <- as.numfac(levs$xDay)
  
  current.asr <- asreml(fixed = log.Turbidity ~ Benches + Sources + Type + Species +
                          Sources:Type + Sources:Species + 
                          Sources:xDay + 
                          Species:xDay + Species:Date,
                        data = WaterRunoff.dat, keep.order = TRUE)
  current.asrt <- asrtests(current.asr, NULL, NULL)
  
  diffs <- predictPlus(asreml.obj = current.asr, 
                       classify="Species:Date:xDay", 
                       term = "Species:Date", 
                       present=c("Type","Species","Sources"), 
                       x.num = "xDay", x.fac = "Date", 
                       x.pred.values=sort(unique(WaterRunoff.dat$xDay)),
                       x.plot.values=c(0,28,56,84), tables = "none",
                       wald.tab = current.asrt$wald.tab)
  testthat::expect_is(diffs, "alldiffs")
  diffs.p <- predictPlus(asreml.obj = current.asr, 
                         classify="Species:Date:xDay", 
                         term = "Species:Date", 
                         parallel = TRUE, levels=levs, 
                         present=c("Type","Species","Sources"), 
                         x.num = "xDay", x.fac = "Date", 
                         x.plot.values=c(0,28,56,84), tables = "none",
                         wald.tab = current.asrt$wald.tab)
  
  testthat::expect_is(diffs.p, "alldiffs")
  testthat::expect_identical(diffs, diffs.p)
})

cat("#### Test for plotPredictions.asreml3\n")
test_that("plotPredictions_asreml3", {
  skip_if_not_installed("asreml")
  skip_on_cran()
  library(asreml)
  library(asremlPlus)
  library(ggplot2)
  unloadNamespace("asreml4")
  data(WaterRunoff.dat)
  current.asr <- asreml(fixed = log.Turbidity ~ Benches + Sources + Type + Species +
                          Sources:Type + Sources:Species + 
                          Sources:xDay + Species:xDay + Species:Date,
                        data = WaterRunoff.dat, keep.order = TRUE)
  current.asrt <- asrtests(current.asr, NULL, NULL)
  predictions <- asreml:::predict.asreml(current.asr, class="Species:Date:xDay", 
                                         present = c("Type","Species","Sources"),
                                         levels=list(xDay=sort(unique(WaterRunoff.dat$xDay))))$predictions$pvals
  predictions <- predictions[predictions$est.status == "Estimable",]
  
  x.title <- "Days since first observation"
  names(x.title) <- "xDay"
  plotPredictions(classify="Species:Date:xDay", y = "predicted.value", 
                  data = predictions, wald.tab = current.asrt$wald.tab, 
                  x.num = "xDay", x.fac = "Date", 
                  titles = x.title,
                  y.title = "Predicted log(Turbidity)",
                  present = c("Type","Species","Sources"),
                  error.intervals = "none", 
                  ggplotFuncs = list(ggtitle("Transformed turbidity over time")))
  
  
  testthat::expect_warning(diffs <- predictPlus(classify="Species:Date:xDay", 
                                                present=c("Type","Species","Sources"), 
                                                asreml.obj = current.asr, 
                                                x.num = "xDay", x.fac = "Date", 
                                                x.pred.values=sort(unique(WaterRunoff.dat$xDay)),
                                                x.plot.values=c(0,28,56,84),
                                                wald.tab = current.asrt$wald.tab))
  plotPredictions(classify="Species:Date:xDay", y = "predicted.value", 
                  data = diffs$predictions, wald.tab = current.asrt$wald.tab, 
                  x.num = "xDay", x.fac = "Date", 
                  titles = x.title,
                  y.title = "Predicted log(Turbidity)")
  testthat::expect_silent("dummy")
})

cat("#### Test for predictPresent.asreml3\n")
test_that("predictPresent_asreml3", {
  skip_if_not_installed("asreml")
  skip_on_cran()
  library(asreml)
  library(asremlPlus)
  library(ggplot2)
  library(dae)
  unloadNamespace("asreml4")
  data(WaterRunoff.dat)
  
  titles <- list("Days since first observation", "Days since first observation", "pH", "Turbidity (NTU)")
  names(titles) <- names(WaterRunoff.dat)[c(5,7,11:12)]
  current.asr <- asreml(fixed = log.Turbidity ~ Benches + Sources + Type + Species + 
                          Sources:Type + Sources:Species + Sources:Species:xDay + 
                          Sources:Species:Date, 
                        data = WaterRunoff.dat, keep.order = TRUE)
  current.asrt <- asrtests(current.asr, NULL, NULL)
  #Example that fails because Date has levels that are not numeric in nature
  testthat::expect_error(diff.list <- predictPresent.asreml(asreml.obj = current.asrt$asreml.obj, 
                                                            terms = "Date:Sources:Species", 
                                                            wald.tab = current.asrt$wald.tab, 
                                                            x.fac = "Date", 
                                                            plots = "predictions", 
                                                            error.intervals = "StandardError", 
                                                            titles = titles, 
                                                            transform.power = 0, 
                                                            present = c("Type","Species","Sources"), 
                                                            tables = "differences", 
                                                            level.length = 6))
  #Example that does not produce predictons because has Date but not xDay
  testthat::expect_output(diff.list <- predictPresent.asreml(asreml.obj = current.asrt$asreml.obj, 
                                                             terms = "Date:Sources:Species", 
                                                             wald.tab = current.asrt$wald.tab, 
                                                             plots = "predictions", 
                                                             error.intervals = "StandardError", 
                                                             titles = titles, 
                                                             transform.power = 0, 
                                                             present = c("Type","Species","Sources"), 
                                                             tables = "differences", 
                                                             level.length = 6), 
                          regexp="All pairwise differences between predicted values")
  testthat::expect_equal(length(diff.list), 1)
  testthat::expect_equal(nrow(diff.list[[1]]$predictions), 0)
  testthat::expect_match(names(diff.list), "Date.Sources.Species")
  
  #### Get the observed combinations of the factors and variables in classify
  class.facs <- c("Sources","Species","Date","xDay")
  levs <- as.data.frame(table(WaterRunoff.dat[class.facs]))
  levs <- levs[do.call(order, levs), ]
  levs <- as.list(levs[levs$Freq != 0, class.facs])
  levs$xDay <- as.numfac(levs$xDay)
  
  # parallel and levels are arguments from predict.asreml
  diff.list <- predictPresent.asreml(asreml.obj = current.asrt$asreml.obj, 
                                     terms = "Date:Sources:Species:xDay",
                                     x.num = "xDay", x.fac = "Date", 
                                     parallel = TRUE, levels = levs, 
                                     wald.tab = current.asrt$wald.tab, 
                                     plots = "predictions", 
                                     error.intervals = "StandardError", 
                                     titles = titles, 
                                     transform.power = 0, 
                                     present = c("Type","Species","Sources"), 
                                     tables = "none", 
                                     level.length = 6)
  testthat::expect_equal(length(diff.list), 1)
  testthat::expect_match(names(diff.list), "Date.Sources.Species.xDay")
})

cat("#### Test for plotPvalues.asreml3\n")
test_that("plotPvalues_asreml3", {
  skip_if_not_installed("asreml")
  skip_on_cran()
  library(asreml)
  library(asremlPlus)
  library(dae)
  library(reshape)
  unloadNamespace("asreml4")
  data(WaterRunoff.dat)
  testthat::expect_output(current.asr <- asreml(fixed = pH ~ Benches + (Sources * (Type + Species)), 
                                                random = ~ Benches:MainPlots,
                                                keep.order=TRUE, data= WaterRunoff.dat))
  current.asrt <- asrtests(current.asr, NULL, NULL)
  diffs <- predictPlus.asreml(classify = "Sources:Type", 
                              asreml.obj = current.asr, tables = "none", 
                              wald.tab = current.asrt$wald.tab, 
                              present = c("Type","Species","Sources"))
  testthat::expect_is(diffs, "alldiffs")
  
  p <- within(reshape::melt(diffs$p.differences), 
              { 
                X1 <- factor(X1, levels=dimnames(diffs$p.differences)[[1]])
                X2 <- factor(X2, levels=levels(X1))
              })
  names(p)[match("value", names(p))] <- "p"
  plotPvalues(p, x = "X1", y = "X2", gridspacing = rep(c(3,4), c(4,2)), 
              show.sig = TRUE)
  
  #Plot with sections
  pdata <- plotPvalues(diffs, sections = "Sources", show.sig = TRUE)
  testthat::expect_equal(nrow(pdata), 400)
  testthat::expect_equal(ncol(pdata), 5)
  testthat::expect_true(all(c("X1","X2","p","sections1","sections2") %in% names(pdata)))
  
  #Plot without sections, but automatic gridspacing
  pupdata <- plotPvalues(diffs, show.sig = TRUE, factors.per.grid = 1)
  testthat::expect_equal(nrow(pupdata), 400)
  testthat::expect_equal(ncol(pupdata), 3)
  testthat::expect_true(all(c("X1","X2","p") %in% names(pupdata)))
  testthat::expect_equal(sum(!is.na(pupdata$p)), 380)

  #Plot without sections, but automatic gridspacing and upper triangle
  pupdata <- plotPvalues(diffs, show.sig = TRUE, factors.per.grid = 1, 
                         triangles = "upper")
  testthat::expect_equal(nrow(pupdata), 400)
  testthat::expect_equal(ncol(pupdata), 3)
  testthat::expect_true(all(c("X1","X2","p") %in% names(pupdata)))
  testthat::expect_equal(sum(!is.na(pupdata$p)), 190)
  
  
  #Plot without sections, but manual gridspacing and upper triangle
  pupdata <- plotPvalues(diffs, show.sig = TRUE, gridspacing = rep(c(3,4), c(4,2)), 
                         triangles = "upper")
  testthat::expect_equal(nrow(pupdata), 400)
  testthat::expect_equal(ncol(pupdata), 3)
  testthat::expect_true(all(c("X1","X2","p") %in% names(pupdata)))
  testthat::expect_equal(sum(!is.na(pupdata$p)), 190)

  #Plot without sections, but manual gridspacing and lower triangle
  pupdata <- plotPvalues(diffs, sections = "Sources", show.sig = TRUE, triangles = "upper")
  pupdata <- na.omit(pupdata)
  testthat::expect_equal(nrow(pupdata), 190)
  testthat::expect_equal(ncol(pupdata), 5)
  testthat::expect_true(all(c("X1","X2","p","sections1","sections2") %in% names(pupdata)))
})


cat("#### Test for plotPvalues.asreml3\n")
test_that("plotPvalues_asreml3", {
  skip_if_not_installed("asreml")
  skip_on_cran()
  library(asreml)
  library(asremlPlus)
  library(dae)
  library(reshape)
  unloadNamespace("asreml4")
  LeafSucculence.diff <- readRDS("./data/LeafSucculence.diff")
  LeafSucculence.diff <- LeafSucculence.diff[[1]]
  
  pdata <- plotPvalues(LeafSucculence.diff, gridspacing = 3, show.sig = TRUE, 
                       axis.labels = TRUE)
  testthat::expect_equal(nrow(pdata), 144)
  testthat::expect_equal(ncol(pdata), 3)
  testthat::expect_true(all(c("X1","X2","p") %in% names(pdata)))
  
  pdata <- plotPvalues(LeafSucculence.diff, factors.per.grid = 2, show.sig = TRUE, 
                       axis.labels = TRUE)
  testthat::expect_equal(nrow(pdata), 144)
  testthat::expect_equal(ncol(pdata), 3)
  testthat::expect_true(all(c("X1","X2","p") %in% names(pdata)))
  
  pdata <- plotPvalues(LeafSucculence.diff, sections = c("Depths","Slope"), 
                       show.sig = TRUE, axis.labels = TRUE)
  testthat::expect_equal(nrow(pdata), 144)
  testthat::expect_equal(ncol(pdata), 5)
  testthat::expect_true(all(c("X1","X2","p","sections1","sections2") %in% names(pdata)))
  
})

cat("#### Test for factor combinations asreml3\n")
test_that("factor.combinations_asreml3", {
  skip_if_not_installed("asreml")
  skip_on_cran()
  library(asreml)
  library(asremlPlus)
  library(dae)
  library(reshape)
  unloadNamespace("asreml4")
  LeafSucculence.diff <- readRDS("./data/LeafSucculence.diff")
  LeafSucculence.diff <- LeafSucculence.diff[[1]]
  
  LeafSucculence.diff <- recalcLSD.alldiffs(LeafSucculence.diff, meanLSD.type = "factor.combinations", 
                                            LSDby = "Species")
  testthat::expect_silent(LeafSucculence.diff <- redoErrorIntervals.alldiffs(LeafSucculence.diff, 
                                                                             error.intervals = "half"))
  testthat::expect_equal(nrow(LeafSucculence.diff$LSD), 3)
  testthat::expect_equal(ncol(LeafSucculence.diff$LSD), 3)
  testthat::expect_true(all(c("P1","P2","P3") %in% rownames(LeafSucculence.diff$LSD)))
  testthat::expect_true("lower.halfLeastSignificant.limit" %in% names(LeafSucculence.diff$predictions))
  testthat::expect_true(names(LeafSucculence.diff$predictions)[length(names(
    LeafSucculence.diff$predictions))] == "est.status")
  
})

cat("#### Test for recalcLSD.alldiffs asreml3\n")
test_that("recalcLSD.alldiffs_asreml3", {
  skip_if_not_installed("asreml")
  skip_on_cran()
  library(asreml)
  library(asremlPlus)
  library(dae)
  library(reshape)
  unloadNamespace("asreml4")
  data(WaterRunoff.dat)
  testthat::expect_output(current.asr <- asreml(fixed = pH ~ Benches + (Sources * (Type + Species)), 
                                                random = ~ Benches:MainPlots,
                                                keep.order=TRUE, data= WaterRunoff.dat))
  current.asrt <- asrtests(current.asr, NULL, NULL)
  diffs <- predictPlus.asreml(classify = "Sources:Type", 
                              asreml.obj = current.asr, tables = "none", 
                              wald.tab = current.asrt$wald.tab, 
                              present = c("Type","Species","Sources"))
  testthat::expect_is(diffs, "alldiffs")
  
  diffs <- redoErrorIntervals.alldiffs(diffs, error.intervals = "halfLeastSignificant")
  testthat::expect_true("upper.halfLeastSignificant.limit" %in% names(diffs$predictions))
  diffs <- recalcLSD.alldiffs(diffs, meanLSD.type = "factor.combinations", LSDby = "Sources")
  testthat::expect_equal(nrow(diffs$LSD), 6)
  testthat::expect_equal(ncol(diffs$LSD), 3)
  
})


