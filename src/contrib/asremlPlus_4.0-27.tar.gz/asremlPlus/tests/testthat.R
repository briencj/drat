Sys.setenv("R_TESTS" = "")
library(testthat)
#Need to execute the following for manual checking
#Sys.setenv(NOT_CRAN = "true")
#test_check("asremlPlus", filter = "3")
#test_check("asremlPlus", filter = "4")
test_check("asremlPlus")
